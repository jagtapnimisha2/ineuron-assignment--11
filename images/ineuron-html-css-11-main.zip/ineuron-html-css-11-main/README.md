# Project-11 HTML & CSS Full Stack Javascript Web Development Course

![image](https://img.shields.io/badge/iNeuron-Full--Stack%20JavaScript%20Web%20Development%20Course-blue)
![image](https://img.shields.io/badge/Hitesh%20Choudhry-LOC-brightgreen)
![image](https://img.shields.io/badge/HTML-CSS-orange)
![image](https://img.shields.io/badge/Project-11-blue)

![image](https://img.shields.io/badge/Rohtash-Talan-blue)

[<img src= "https://img.shields.io/badge/projcet live link-10b?style=for-the-badge&logo=&logoColor=white" />](https://ineuron-html-css-11.netlify.app/)

## About

This project is created using HTML and CSS. I have used CSS Positioning, flex-box and grid build this project, and this project is fully responsive.

## What did I learn by making this project?

-   learn about CSS grid layout.

## Time taken to finish this project?

This project took me around 6 and half hour to finish.


## Screenshots

![image](./Screenshot1.png)
![image](./Screenshot.png)

[<img src= "https://img.shields.io/badge/PROJCET LINK-20b?style=for-the-badge&logo=&logoColor=white" />](https://ineuron-html-css-11.netlify.app/)
